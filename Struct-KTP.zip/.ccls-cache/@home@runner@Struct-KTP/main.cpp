 #include <iostream>
#include <fstream>

using namespace std;

struct ktp {
  char NIK[16], rtrw[6], tgl[10];
  string nama, alamat, kel, kec, pekerjaan, ttl;
  string jk, agama, kawin, goldar, warga;
};

class dataKTP {

	friend ostream& operator << (ostream&, const dataKTP&);
	friend istream& operator >> (istream&, dataKTP&);
		
public:
  ktp data[10];

  bool countNIK(char);
  void cekWarga(int);
  
};

//Input
istream& operator >> (istream& in, dataKTP& io) {
  int n;
  cout << "Banyak data yang akan dimasukkan: ";
  in >> n;

  //Input data KTP sesuai dengan banyak KTP yang dimasukkan
  int pil;
  for (int i = 0; i < n; i++) {
    cout << "\n========================================\n";
    cout << "NIK\t: ";
    in >> io.data[i].NIK;
    cout << "Nama\t: ";
    in.ignore();
    getline(in, io.data[i].nama);
    
    cout << "Jenis Kelamin:\n";
    cout << "1. Laki - Laki\n";
    cout << "2. Perempuan\n";
    cout << "Pilih: ";
    in >> pil;
    if (pil == 1) {
        io.data[i].jk = "LAKI-LAKI";
    } else if (pil == 2) {
        io.data[i].jk = "PEREMPUAN";
    } else {
      cout << "Pilihan tidak valid\n";
    }

    cout << "Golongan Darah:\n";
    cout << "1. A\n";
    cout << "2. B\n";
    cout << "3. AB\n";
    cout << "4. O\n";
    cout << "Pilih: ";
    in >> pil;
    if (pil == 1) {
        io.data[i].goldar = "A";
    } else if (pil == 2) {
        io.data[i].goldar = "B";
    } else if (pil == 3) {
        io.data[i].goldar = "AB";
    } else if (pil == 4) {
        io.data[i].goldar = "O";
    } else {
      cout << "Pilihan tidak valid\n";
    }

    cout << "TTL\t\t:";
    in.ignore();
    getline(in, io.data[i].ttl);
    cout << "Alamat\t:";
    getline(in, io.data[i].alamat);
    cout << "RT/RW\t:";
    in >> io.data[i].rtrw;
    cout << "Kel/Desa\t:";
    in >> io.data[i].kel;
    cout << "Kecamatan\t:";
    in >> io.data[i].kec;
    
    cout << "Agama:\n";
    cout << "1. Islam\n";
    cout << "2. Kristen Protestan\n";
    cout << "3. Katolik\n";
    cout << "4. Hindu\n";
    cout << "5. Konghucu\n";
    cout << "6. Buddha\n";
    cout << "Pilih: ";
    in >> pil;
    if (pil == 1) {
        io.data[i].agama = "ISLAM";
    } else if (pil == 2) {
        io.data[i].agama = "KRISTEN";
    } else if (pil == 3) {
        io.data[i].agama = "KATOLIK";
    } else if (pil == 4) {
        io.data[i].agama = "HINDU";
    } else if (pil == 5) {
        io.data[i].agama = "KONGHUCU";
    } else if (pil == 6) {
        io.data[i].agama = "BUDDHA";
    } else {
      cout << "Pilihan tidak valid\n";
    }
    
    cout << "Status Perkawinan :\n";
    cout << "1. KAWIN\n";
    cout << "2. BELUM KAWIN\n";
    cout << "Pilih: ";
    in >> pil;
    if (pil == 1) {
        io.data[i].kawin = "KAWIN";
    } else if (pil == 2) {
        io.data[i].kawin = "BELUM KAWIN";
    } else {
      cout << "Pilihan tidak valid\n";
    }
    
    cout << "Pekerjaan\t:";
    in.ignore();
    getline(in, io.data[i].pekerjaan);
    
    cout << "Kewarganegaraan:\n";
    cout << "1. Warga Negara Indonesia\n";
    cout << "2. Warga Negara Asing\n";
    cout << "Pilih: ";
    in >> pil;
    if (pil == 1) {
        io.data[i].warga = "WNI";
    } else if (pil == 2) {
        io.data[i].warga = "WNA";
    } else {
      cout << "Pilihan tidak valid\n";
    }
    
    cout << "Berlaku Hingga\t: ";
    in >> io.data[i].tgl;
  }

  //Tulis data ke dalam file
  ofstream ofs;
  ofs.open("data.txt");
  for (int i = 0; i < n; i++) {
   ofs << "Data Ke-" << i + 1 << ":\n";
    ofs << "========================================\n";
    ofs << "NIK\t\t\t: " << io.data[i].NIK << "\n\n";
	  ofs << "Nama\t\t\t: " << io.data[i].nama << endl;
	  ofs << "Tempat/Tgl Lahir\t: " << io.data[i].ttl << endl;
	  ofs << "Jenis Kelamin\t\t: " << io.data[i].jk << "\tGol. Darah : " << io.data[i].goldar << endl;
	  ofs << "Alamat\t\t\t: " << io.data[i].alamat << endl;
		ofs << "\tRT/RW\t\t: " << io.data[i].rtrw << endl;
		ofs << "\tKel/Desa\t: " << io.data[i].kel << endl;
		ofs << "\tKecamatan\t: " << io.data[i].kec << endl;
	  ofs << "Agama\t\t\t: " << io.data[i].agama << endl;
	  ofs << "Status Perkawinan\t: " << io.data[i].kawin << endl;
	  ofs << "Pekerjaan\t\t: " << io.data[i].pekerjaan << endl;
	  ofs << "Kewarganegaraan\t\t: " << io.data[i].warga << endl;
	  ofs << "Berlaku Hingga\t\t: " << io.data[i].tgl << endl;
    ofs << "========================================\n";
  }
  ofs.close();

}
//Output
ostream& operator << (ostream& out, const dataKTP& outp) {
  string l;
  ifstream ifs;
  ifs.open("data.txt");
  if (ifs.is_open()) {
    while (getline(ifs, l)) {
      out << l << "\n";
    }
    ifs.close();
  } else {
    out << "Data tidak ada";
    return out;
  } 
}


int main() {
  dataKTP n;

  cin >> n;
  
  cout << n;
}